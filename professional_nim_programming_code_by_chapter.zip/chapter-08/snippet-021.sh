echo %*{"ts": $now(), "level": "info", "msg": "started", "port": port}

import nats

let n = newNatsClient()
n.connect("nats://localhost:4222")
n.publish("events", "hello")
n.subscribe("events") do (msg: NatsMsg):
  echo "got: ", msg.data
Kafka: use librdkafka via FFI or generated bindings. Wrap producers/consumers behind Port definitions (like in previous chapters).
